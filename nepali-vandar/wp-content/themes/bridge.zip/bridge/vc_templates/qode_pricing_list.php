<div class="qode_pricing_list">
	<ul class="qode_pricing_list_holder">
		<?php echo do_shortcode($content); ?>
	</ul> <!-- close ul.qode_pricing_list_holder -->
</div> <!-- close div.qode_pricing_list -->